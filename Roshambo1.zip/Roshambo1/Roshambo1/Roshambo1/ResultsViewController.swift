//
//  File.swift
//  Roshambo1
//
//  Created by Pham, Nam B on 7/7/16.
//  Copyright © 2016 Pham, Nam B. All rights reserved.
//
import UIKit
import Foundation

enum Shape: String{
    case Rock = "Rock"
    case Paper = "Paper"
    case Scissors = "Scissors"
    
    static func computerChoice()-> Shape {
        let shapes = ["Rock", "Paper", "Scissors"]
        let randomChoice = Int(arc4random_uniform(3))
        return Shape(rawValue: shapes[randomChoice])!
    }
}

class ResultsViewController: UIViewController {
    
  
    @IBOutlet private weak var resultImage: UIImageView!
    @IBOutlet private weak var gameResult: UILabel!
    var playerChoice: Shape!
    private let computerChoice: Shape = Shape.computerChoice()
    
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(animated)
        displayResult()
    }
    
  
    private func displayResult() {
        
        var imageName: String
        var text: String
        let matchup = "\(playerChoice.rawValue) vs. \(computerChoice.rawValue)"
        
       
        switch (playerChoice!, computerChoice) {
        case let (user, opponent) where user == opponent:
            text = "\(matchup): it's a tie!"
            imageName = "tie"
        case (.Rock, .Scissors), (.Paper, .Rock), (.Scissors, .Paper):
            text = "You win with \(matchup)!"
            imageName = "\(playerChoice.rawValue)-\(computerChoice.rawValue)"
        default:
            text = "You lose with \(matchup) :(."
            imageName = "\(computerChoice.rawValue)-\(playerChoice.rawValue)"
        }
        
        imageName = imageName.lowercaseString
        resultImage.image = UIImage(named: imageName)
        gameResult.text = text
    }
    
    @IBAction private func PlayAgain() {
        dismissViewControllerAnimated(true, completion: nil)
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
}

