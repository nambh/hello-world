//
//  ViewController.swift
//  Roshambo1
//
//  Created by Pham, Nam B on 7/7/16.
//  Copyright © 2016 Pham, Nam B. All rights reserved.
//  Most of the code from Udacity

import UIKit

class ChoiceViewController: UIViewController {

// All code
    
    @IBAction private func clickRock(sender: UIButton){
        
        let vc = self.storyboard?.instantiateViewControllerWithIdentifier("ResultsViewController") as! ResultsViewController
        vc.playerChoice = getUserShape(sender)
        presentViewController(vc, animated: true, completion: nil)
    }
    
    // Segue with Code
    
    @IBAction private func playPaper(sender: UIButton) {
        performSegueWithIdentifier("play", sender: sender)
    }
    
    // Segue
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        if segue.identifier == "play" {
            let vc = segue.destinationViewController as! ResultsViewController
            vc.playerChoice = getUserShape(sender as! UIButton)
        }
    }
    
    private func getUserShape(sender: UIButton) -> Shape {
        let shape = sender.titleForState(.Normal)!
        return Shape(rawValue: shape)!
    }
}

